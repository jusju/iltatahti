# Kumimoottorilennokin potkuripukki — uudelleensuunnittelu 1.11.2026

## Mitat ja oletukset
- Runkoputki ulko-Ø 10,0 mm; oletettu seinämä 0,8 mm.
- Pukin rungon hylsyn reikä Ø 10,2 mm (10 mm putken sovite pitää tarkistaa tulostamalla).
- Potkurin akseli Ø 0,8 mm; mallinnettu reikä Ø 0,95 mm.
- Akselilinjan etäisyys runkoputken keskilinjasta 12 mm X-suuntaan.
- Akseliputki / ohjainholkki Ø 3,3 mm ulkoa, pituus 5 mm.
- Sivuveto 2 astetta, oletettu XZ-tasoon (tarkista suunnan oikeellisuus rakennettavassa koneessa).
- Runkoputken sisäänmeno 5 tai 10 mm.
- PLA:n oletettu tiheys 1,24 g/cm³; massa = CAD-solidin tilavuus × tiheys.

## Kolme rakennetta / kaksi syvyyttä
1. `plate`: vertailumalli, keskeiset suorat tuet.
2. `lateral_V`: **sivusuunnan V-kolmio** XY-tasossa, käyttäjän korjaaman ajatuksen mukaan (90° aiempaan XZ-tasossa olleeseen V-rakenteeseen).
3. `bio_lattice`: haaroittuvien, kapenevien tankojen rakenteellinen konsepti. Tämä on generative design -henkinen *käsin parametrisoitu* vaihtoehto, ei topologiaoptimoinnin matemaattinen globaaliratkaisu.

## Massat (teoreettinen umpikappale PLA:sta)
| Malli | Tilavuus mm³ | Massa g |
|---|---:|---:|
| levy, 5 mm | 205.861 | 0.2553 |
| sivu-V, 5 mm | 208.664 | 0.2587 |
| bio, 5 mm | 219.959 | 0.2727 |
| levy, 10 mm | 348.838 | 0.4326 |
| sivu-V, 10 mm | 346.894 | 0.4301 |
| bio, 10 mm | 366.706 | 0.4547 |

## Jäykkyysvertailu: yksinkertaistettu 3D-palkki-FEM, 10 mm mallit
Kuormitus 0,1 N akseliholkin keskipisteeseen yksi suunta kerrallaan; oletettu lineaarinen kimmokerroin E = 2000 N/mm² ja Poisson 0,35. Rungon hylsyn tuet oletetaan täysin jäykiksi; rakenteiden tuet kuvataan poikkileikkaukseltaan pyöreinä palkkielementteinä, ei STL:n täytenä solidigeometriana. Siksi luvut ovat **suuntaa-antavia vain** eivätkä ennusta tulostetun kappaleen kestävyyttä.

| Malli | dx 0,1N (mm) | dy 0,1N (mm) | dz 0,1N (mm) |
|---|---:|---:|---:|
| levy | 0.000057 | 0.002730 | 0.000350 |
| sivu-V | 0.000109 | 0.000512 | 0.010225 |
| bio | 0.000092 | 0.000466 | 0.001079 |

**Tulkinta:** sivu-V on tämän palkkimallin mukaan noin 5,3× jäykempi Y-sivukuormalla kuin levy, mutta paljon pehmeämpi Z-kuormalla. Bio-haarautuminen tarjoaa lähes saman sivujäykkyyden kuin V ja selvästi paremman Z-jäykkyyden, hieman suuremmalla massalla. Tuloksiin vaikuttaa voimakkaasti jäykän hylsyn oletus, kiinnitys ja palkkireduktio.

## Tärkeitä varoituksia
- Täydellistä 3D-tilavuuselementtien FEM-analyysia ja jännityskeskittymien lujuustarkastelua **ei** ole tehty. Palkki-FEM ei ole lujuustodistus. Ei määritetty todellista murtokuormaa tai väsymiskestävyyttä.
- Johtopäätös paras *kaikilla* kuormilla ei ole perusteltu; suosittelen alustavasti `bio_lattice_10mm` kompromissiksi. Jos jokainen milligramma on tärkeä, 5 mm versio on kevyempi mutta putkiliitoksen lujuus pitää erikseen varmistaa.
- Tulosta koepala ja kokeile 10,2 mm runkoaukon sovitetta. 0,95 mm akseliaukko voi tarvita jälkityöstön 0,8 mm akselille.
- Ohuet tukitangot ~1,0–1,9 mm halkaisijaltaan. Valitse tulostusasento huolella: kerrosrajat ja yläpuoliset ulokkeet voivat vaatia tuet. 0,4 mm suutin, 0,12–0,16 mm kerrokset ehdotuksena.
- Sivuveto voi olla eri merkkinen halutun pyörimissuunnan mukaan.

## Sisällys
- kuusi `*.stl`-tulostusverkkoa (tarkistettu vesitiiviiksi), kuusi `*.step` CAD-kappaletta
- `make_mount.py` CadQuery-mallien generointiin
- `fem_proxy.py` avoin laskenta, joka tekee 3D-palkki-FEM-vertailun
- `render_mount.py` VTK/FFmpeg-videon lähdekoodi
- `pukki_bio_3akselia.mp4` 8 sekunnin jatkuva pyöriminen X-, Y- ja Z-akseleilla samaan aikaan
- `esikatselu.png` videon yksittäinen ruutu
- `massat.json` CAD-massat

## Käyttö
`python make_mount.py` (tarvitsee cadqueryn). `python fem_proxy.py` (numpy). `python render_mount.py` (vtk ja ffmpeg).
