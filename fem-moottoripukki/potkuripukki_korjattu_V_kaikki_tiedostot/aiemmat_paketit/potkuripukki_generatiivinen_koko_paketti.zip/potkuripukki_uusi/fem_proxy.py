"""Approximate 3D Euler-Bernoulli frame FEM: sleeve assumed rigid.
Use only for conceptual comparison. Not solid FEM, not strength validation.
Geometry: 10 mm engagement; axes x towards bearing, y lateral, z sleeve axis.
Loads 0.1 N at bearing centre, E=2GPa, Poisson=0.35.
"""
import numpy as np
E=2000 # N/mm2 (PLA, approximate)
nu=.35;G=E/(2*(1+nu)); depth=10

def solve(style,force_axis):
 nodes=[];fixed=set();elems=[]
 def nid(p,clamp=False):
  p=np.array(p,dtype=float)
  for i,q in enumerate(nodes):
   if np.linalg.norm(q-p)<1e-7:
    if clamp:fixed.add(i)
    return i
  nodes.append(p)
  if clamp:fixed.add(len(nodes)-1)
  return len(nodes)-1
 def beam(a,b,r1,r2=None,clamp_a=False):
  i=nid(a,clamp_a);j=nid(b);elems.append((i,j,(r1 if r2 is None else (r1+r2)/2)))
 hub=(12,0,5);nid(hub)
 if style=='plate':
  for z in (2.5,7.5):beam((5.5,0,z),hub,1.05,clamp_a=True)
 elif style=='lateral_V':
  for y in (-3.4,3.4):beam((4.5,y,5),hub,.85,clamp_a=True)
 elif style=='bio_lattice':
  for zo in (-.22,.22):
   z=10*(.5+zo)
   for sign in (-1,1):
    a=(4.1,sign*3.65,z);m=(8,sign*2.10,5+zo*4.5);tip=(11.65,sign*.55,5)
    beam(a,m,.82,clamp_a=True);beam(m,tip,.65);beam(tip,hub,.58)
  for sign in (-1,1):
   beam((8,sign*2.1,4.01),(8,sign*2.1,5.99),.55)
  # smaller branches to semi-rigid sleeve
  for sign in (-1,1):beam((5.2,sign*2.5,5),(8,sign*2.05,5),.52,clamp_a=True)
 n=len(nodes);K=np.zeros((6*n,6*n));
 for i,j,r in elems:
  vec=nodes[j]-nodes[i];L=np.linalg.norm(vec);ex=vec/L
  aux=np.array([0.,0.,1.]) if abs(ex[2])<.95 else np.array([0.,1.,0.]);ey=np.cross(aux,ex);ey/=np.linalg.norm(ey);ez=np.cross(ex,ey)
  R=np.vstack([ex,ey,ez]); T=np.zeros((12,12))
  for k in range(4):T[k*3:k*3+3,k*3:k*3+3]=R
  A=np.pi*r*r;I=np.pi*r**4/4;J=2*I
  k=np.zeros((12,12))
  def add_pair(a,b,c):k[a,a]+=c;k[b,b]+=c;k[a,b]-=c;k[b,a]-=c
  add_pair(0,6,E*A/L);add_pair(3,9,G*J/L)
  # transverse translations v,w with rotations rz,ry respectively
  for v,rot,sgn in [(1,5,1),(2,4,-1)]:
   inds=[v,rot,v+6,rot+6];fac=E*I/L**3
   mat=np.array([[12,6*L*sgn,-12,6*L*sgn],[6*L*sgn,4*L*L,-6*L*sgn,2*L*L],[-12,-6*L*sgn,12,-6*L*sgn],[6*L*sgn,2*L*L,-6*L*sgn,4*L*L]])*fac
   k[np.ix_(inds,inds)]+=mat
  dofs=list(range(6*i,6*i+6))+list(range(6*j,6*j+6));K[np.ix_(dofs,dofs)]+=T.T@k@T
  # clamp roots
 free=[d for d in range(6*n) if d//6 not in fixed];f=np.zeros(6*n);f[nodes.index(next(q for q in nodes if np.linalg.norm(q-np.array(hub))<1e-7))*6+force_axis]=.1
 try:
  disp=np.linalg.solve(K[np.ix_(free,free)],f[free]);u=np.zeros(6*n);u[free]=disp
  return round(float(u[force_axis]),6)
 except np.linalg.LinAlgError:return None

if __name__=='__main__':
 for s in ['plate','lateral_V','bio_lattice']:
  print(s,{'x':solve(s,0),'y':solve(s,1),'z':solve(s,2)})
