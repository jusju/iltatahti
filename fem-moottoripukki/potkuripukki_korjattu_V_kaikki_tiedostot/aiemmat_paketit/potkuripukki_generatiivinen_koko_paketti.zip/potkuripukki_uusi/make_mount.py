import cadquery as cq, math, pathlib, json, zipfile, textwrap
import numpy as np
P=pathlib.Path('/mnt/data/potkuripukki_uusi');P.mkdir(exist_ok=True)
V=cq.Vector
# frame: sleeve axis Z, shaft axis Z (2 deg thrust), desired transverse triangular ribs in XY

def rod(a,b,r0,r1=None):
 a,b=V(*a),V(*b); v=b-a; n=v.normalized(); L=v.Length
 if r1 is None:r1=r0
 return cq.Solid.makeCone(r0,r1,L,a,n) if r0!=r1 else cq.Solid.makeCylinder(r0,L,a,n)
def node(x,r):return cq.Solid.makeSphere(r,V(*x),angleDegrees1=-90,angleDegrees2=90)
def build(style,depth):
 # 10.2 mm bore assumes 0.2mm clearance on 10 mm OD carbon fuselage tube
 sleeve=cq.Solid.makeCylinder(5.9,depth,V(0,0,0),V(0,0,1)).cut(cq.Solid.makeCylinder(5.1,depth+2,V(0,0,-1),V(0,0,1)))
 ax=V(math.sin(math.radians(2)),0,math.cos(math.radians(2)))
 hcenter=V(12,0,depth/2)
 bearing=cq.Solid.makeCylinder(1.65,5.0,hcenter-ax*2.5,ax)
 solids=[sleeve,bearing]
 def add(a,b,r0,r1=None):solids.append(rod(a,b,r0,r1));solids.append(node(a,r0));solids.append(node(b, r0 if r1 is None else r1))
 if style=='plate':
  # reference web straddles centerline
  for z in (depth*.25,depth*.75):add((5.5,0,z),(12,0,depth/2),1.05)
 elif style=='lateral_V':
  # 90 degree rotation of earlier vertical triangle: lateral brace set on XY plane
  z=depth/2
  for y in (-3.4,3.4):add((4.5,y,z),(12,0,z),.94,.77)
  add((5.7,-3.0,z),(5.7,3.0,z),.65)
 elif style=='bio_lattice':
  # Tree-inspired tapered bifurcation. Pair of laterally separated primary roots,
  # two stabilizers across height, and slender edge gussets.
  for zoff in (-.22,.22):
   z=depth*(.5+zoff)
   for sign in (-1,1):
    start=(4.1,sign*3.65,z)
    mid=(8.0,sign*2.10,depth*.5+zoff*.45*depth)
    tip=(11.65,sign*.55,depth*.5)
    add(start,mid,.94,.71)
    add(mid,tip,.72,.58)
  # lateral oval-ish separation helps torsional resistance
  for sign in (-1,1):
   add((8,sign*2.1,depth*.5-.22*.45*depth),(8,sign*2.1,depth*.5+.22*.45*depth),.55)
  # diagonally branched curved-lightning ribs on left and right, in XY plane
  for sign in (-1,1):
   add((5.2,sign*2.5,depth*.5),(7.9,sign*2.05,depth*.5),.56,.48)
 else:raise ValueError(style)
 result=solids[0]
 for x in solids[1:]:result=result.fuse(x)
 result=result.clean()
 # ream bores last to avoid covered openings
 bore=cq.Solid.makeCylinder(5.1,depth+3,V(0,0,-1.5),V(0,0,1))
 shaft=cq.Solid.makeCylinder(.475,8,hcenter-ax*4,ax)
 result=result.cut(bore).cut(shaft).clean()
 return result
rows=[]
for dep in [5,10]:
 for typ in ['plate','lateral_V','bio_lattice']:
  shape=build(typ,dep)
  name=f'pukki_{typ}_{dep}mm'
  cq.exporters.export(shape,str(P/(name+'.stl')),tolerance=.035,angularTolerance=.16)
  cq.exporters.export(shape,str(P/(name+'.step')))
  rows.append({'model':name,'volume_mm3':round(shape.Volume(),3),'PLA_g':round(shape.Volume()*0.00124,4),'watertight':None})
(P/'massat.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(rows)
