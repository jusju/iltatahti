import vtk, subprocess, sys
from vtk.util.numpy_support import vtk_to_numpy
from pathlib import Path
P=Path('/mnt/data/potkuripukki_uusi')
reader=vtk.vtkSTLReader();reader.SetFileName(str(P/'pukki_bio_lattice_10mm.stl'));reader.Update()
mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(reader.GetOutputPort())
actor=vtk.vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetColor(.72,.83,.92);actor.GetProperty().SetSpecular(.35);actor.GetProperty().SetSpecularPower(30)
actor.SetOrigin(5.5,0,5)
ren=vtk.vtkRenderer();ren.SetBackground(.07,.09,.12);ren.AddActor(actor)
light=vtk.vtkLight();light.SetPosition(15,20,30);light.SetIntensity(1.5);ren.AddLight(light)
win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.AddRenderer(ren);win.SetSize(640,640)
cam=ren.GetActiveCamera();cam.SetFocalPoint(6,0,5);cam.SetPosition(28,-34,29);cam.SetViewUp(0,0,1);ren.ResetCamera();cam.Zoom(1.35)
wt=vtk.vtkWindowToImageFilter();wt.SetInput(win);wt.SetInputBufferTypeToRGB();wt.ReadFrontBufferOff()
cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','640x640','-framerate','24','-i','-','-c:v','libx264','-pix_fmt','yuv420p','-crf','22',str(P/'pukki_bio_3akselia.mp4')]
proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for i in range(192):
 actor.RotateX(360/192*.7);actor.RotateY(360/192*.83);actor.RotateZ(360/192*.65)
 win.Render();wt.Modified();wt.Update()
 im=wt.GetOutput();a=vtk_to_numpy(im.GetPointData().GetScalars()).reshape(640,640,3)
 proc.stdin.write(a[::-1].tobytes())
proc.stdin.close();r=proc.wait();print('render done',r)
