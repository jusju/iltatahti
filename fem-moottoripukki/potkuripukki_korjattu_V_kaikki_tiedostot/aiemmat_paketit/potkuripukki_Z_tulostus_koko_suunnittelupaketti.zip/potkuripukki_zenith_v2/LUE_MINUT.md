# Potkuripukki: Z-tulostettava sivuttaistuettu prototyyppi (1.11.2026)

## Suunnittelutavoite
Runkoputken akseli on tulostuspöytään nähden pystysuora (Z). Potkuriakseliholkin **alempi pää on samassa Z=0-tasossa** ja osuu tulostuspöytään. Molempien holkkien seinämät kasvavat suoraan ylöspäin. Yhdistävä kapea tukiripa ja sivusuuntaiset tukikolmiot lähtevät alustasta, eivät tyhjästä. Pituussuuntainen runkoputki työnnetään hylsyyn jälkikäteen.

## Mitat
- Runkoputki Ø10,0 mm, seinämä oletuksena 0,8 mm
- Runkohylsyn reikä Ø10,2 mm; ulkohalkaisija 11,7 mm
- Runkoputken sisäänmeno 5 mm tai 10 mm
- Potkuriakseli Ø0,8 mm; reikä CADissa Ø0,95 mm, kannattaa jälkiporata tarkasti
- Potkuriakseliholkin ulko-Ø3,4 mm, pituus 5 mm
- Akseleiden etäisyys 12 mm X-suuntaan
- Akseliin mallinnettu 2° kallistus XZ-tasossa: **ulkoholkin runko on pystysuora, vain sisäreikä kallistuu**. Reiän pohjasuun liikkeen johdosta tulostuksen onnistuminen riippuu viipaloinnista.
- 0,4 mm suutin, suosituskerros 0,12–0,16 mm.

## Mallit ja tulostettavuus
- `spine`: kevein keskiselkäranka, helpoin tulostaa.
- `lateral_V`: tasainen lattiaan tuettu sivuttaiskolmio ja kaksi nousevaa tukea, ensisijainen tulostuskokeen ehdokas.
- `bio`: haaroittuva konsepti; **STL ei läpäissyt vesitiiviystarkastusta**, joten sitä ei tule suoraan käyttää tuotantotulostuksessa ilman mesh-korjausta.

**Huomautus:** Kaikkien ulkopintojen support-vapautta ei ole todistettu viipalointiohjelmalla. Runkoholkkien ja akseliholkin sisäreiät ovat pystysuuntaisia tai lähes pystysuuntaisia. Sivuttaisrivat on muotoiltu tulostusalustaan tukeutuviksi, mutta esimerkiksi varren alkukulmat ja liittymät voivat vaatia säätöä/viipalointitarkistuksen.

## Massa-arviot PLA 1,24 g/cm³, umpikappale
| Versio | 5 mm | 10 mm |
|---|---:|---:|
| Keskiselkäranka | 0,2303 g | 0,3902 g |
| Sivuttais-V | 0,2421 g | 0,4020 g |
| Biomorfinen | 0,2427 g | 0,4027 g |

Massat ovat CAD-tilavuus × materiaalin nimellistiheys; ne eivät sisällä tulosteen pursotuskorjauksia tai reikiin jääneitä pursotuksia.

## FEM-tulokset
**Tälle uudelle Z-tulostusgeometrialle ei ole ajettu validoitua 3D-solid-FEM:iä.** Alkuperäisen paketin `fem_proxy.py` arvioi *vanhojen* rakenteiden palkkimallia. Sen numerot eivät päde uusiin Z-malleihin sellaisenaan. Optimaalisuutta tai kestävyyttä ei siis ole osoitettu laskennallisesti. Uusi geometria on tulostettavuuteen perustuva prototyyppi, ei todistettu generatiivisen optimoinnin lopputulos.

## Paketti
- `create.py` luo kuusi parametrista STEP- ja STL-versiota (CadQuery + trimesh)
- `render.py` luo MP4:n (VTK + ffmpeg), 7 s, kaikkien kolmen akselin pyöritys samanaikaisesti
- `massat_ja_tarkistus.json`: automaattiset tilavuus-, massa- ja mesh-tarkastustulokset
- `alkuperaiset_paketit/`: aikaisemmat ZIP-paketit kokonaisuudessaan, tekstisisältöineen
- `tekstiarkisto/`: tämän chatin tavoite, saatavilla olevien aiempien keskustelujen tekstit ja Work-yhteenvedot Markdownina

## Tärkeimmät tarkistukset ennen käyttöä
1. Tarkista kohdistuuko 2° sivuveto haluttuun suuntaan.
2. Viipaloi `pukki_Z_lateral_V_10mm.stl`, katso kaikkien kerrosten tuki- ja ylitysalueet; älä lisää automaattisia tukia sisäholkkeihin.
3. Mittaa halkaisijat ja sovite. 0,95 mm reikä ja 0,8 mm akseli ovat eri asiat.
4. Tee kevyt käsin tehtävä taipuma- ja vääntötesti ennen lentokäyttöä.
