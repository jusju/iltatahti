import vtk,subprocess
from vtk.util.numpy_support import vtk_to_numpy
from pathlib import Path
P=Path(__file__).parent
r=vtk.vtkSTLReader();r.SetFileName(str(P/'pukki_Z_lateral_V_10mm.stl'));r.Update()
m=vtk.vtkPolyDataMapper();m.SetInputConnection(r.GetOutputPort())
a=vtk.vtkActor();a.SetMapper(m);a.GetProperty().SetColor(.75,.84,.91);a.GetProperty().SetSpecular(.35);a.SetOrigin(6,0,5)
ren=vtk.vtkRenderer();ren.SetBackground(.06,.08,.12);ren.AddActor(a)
w=vtk.vtkRenderWindow();w.SetOffScreenRendering(1);w.AddRenderer(ren);w.SetSize(480,480)
c=ren.GetActiveCamera();c.SetFocalPoint(6,0,5);c.SetPosition(29,-35,26);c.SetViewUp(0,0,1);ren.ResetCamera();c.Zoom(1.3)
f=vtk.vtkWindowToImageFilter();f.SetInput(w);f.SetInputBufferTypeToRGB();f.ReadFrontBufferOff()
p=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pixel_format','rgb24','-video_size','480x480','-framerate','15','-i','-','-c:v','libx264','-pix_fmt','yuv420p','-crf','24',str(P/'pukki_Z_sivuttaisV_3akselia.mp4')],stdin=subprocess.PIPE)
for i in range(105):
 a.RotateX(.86);a.RotateY(.69);a.RotateZ(.73)
 w.Render();f.Modified();f.Update();im=vtk_to_numpy(f.GetOutput().GetPointData().GetScalars()).reshape((480,480,3));p.stdin.write(im[::-1].tobytes())
p.stdin.close();print('video',p.wait())
