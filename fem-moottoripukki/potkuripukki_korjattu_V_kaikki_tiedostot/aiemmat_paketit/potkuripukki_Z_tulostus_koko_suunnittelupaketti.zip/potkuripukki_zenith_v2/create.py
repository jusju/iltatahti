import cadquery as cq, math, pathlib, json, shutil
import trimesh
P=pathlib.Path(__file__).parent
V=cq.Vector

def rod(a,b,r0,r1):
 a,b=V(*a),V(*b);vec=b-a
 return cq.Solid.makeCone(r0,r1,vec.Length,a,vec.normalized())
def sph(p,r):return cq.Solid.makeSphere(r,V(*p))
def make(typ,depth):
 # all bottoms z=0; fuselage axis upright, shaft-bushing bottom on table too
 # keep outer shaft sleeve vertical and add thrust offset by 2 deg only to hole
 outer=cq.Solid.makeCylinder(5.85,depth,V(0,0,0),V(0,0,1))
 hub=cq.Solid.makeCylinder(1.70,5.0,V(12,0,0),V(0,0,1))
 solids=[outer,hub]
 def connect(a,b,r0,r1):solids.append(rod(a,b,r0,r1))
 # foundation is *fully bed-supported* and unites both vertical housings
 # narrow layered lattice ribbons, avoiding broad horizontal ceilings
 if typ=='spine':
  connect((4.9,0,.65),(11.5,0,.65),.78,.69)
  connect((5.0,0,1.1),(11.45,0,3.9),.82,.60)
 elif typ=='lateral_V':
  for s in (-1,1):
   connect((4.3,s*2.5,.64),(11.3,s*.55,.64),.68,.58)
   connect((8.1,s*1.5,.72),(11.4,s*.52,4.15),.69,.57)
  connect((5.05,0,.72),(11.4,0,.72),.55,.48)
 elif typ=='bio':
  # 2 foot-supported lower ribs with upward-growing split branches
  for s in (-1,1):
   connect((4.2,s*2.75,.68),(8.1,s*1.75,.68),.75,.70)
   connect((8.1,s*1.75,.68),(11.6,s*.50,.68),.70,.56)
   connect((8.1,s*1.75,.68),(11.65,s*.52,4.20),.79,.56)
  # no central seam; twin roots grow from the fuselage socket
 else:raise ValueError(typ)
 result=solids[0]
 for s in solids[1:]:result=result.fuse(s)
 # trim base spheres/cones flat: unequivocally on bed
 cutbelow=cq.Solid.makeBox(40,30,10,V(-10,-15,-10))
 result=result.cut(cutbelow)
 # fuselage hole and shaft hole: shaft bore inclined 2 degrees from vertical
 bore=cq.Solid.makeCylinder(5.1,depth+2,V(0,0,-1),V(0,0,1))
 ang=math.radians(2); axis=V(math.sin(ang),0,math.cos(ang))
 hole=cq.Solid.makeCylinder(.475,9,V(12,0,2.5)-axis*4.5,axis)
 result=result.cut(bore).cut(hole).clean()
 return result
records=[]
for depth in (5,10):
 for typ in ('spine','lateral_V','bio'):
  s=make(typ,depth); name=f'pukki_Z_{typ}_{depth}mm'
  cq.exporters.export(s,str(P/(name+'.step')))
  cq.exporters.export(s,str(P/(name+'.stl')),tolerance=.04,angularTolerance=.15)
  mesh=trimesh.load_mesh(P/(name+'.stl'))
  records.append({'model':name,'volume_mm3':round(s.Volume(),2),'PLA_mass_g':round(s.Volume()*0.00124,4),'watertight':bool(mesh.is_watertight),'parts':int(len(mesh.split(only_watertight=False))),'z_min':round(float(mesh.bounds[0,2]),4)})
(P/'massat_ja_tarkistus.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print(json.dumps(records,indent=2))
